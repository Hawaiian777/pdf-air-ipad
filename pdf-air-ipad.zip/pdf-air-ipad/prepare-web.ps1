# Runs automatically while GitHub builds PDF Air for iPad.
# Puts the PDF engine, every font and text recognition into the app, so it works with no internet,
# then lists those files for the offline store (sw.js).
param([string]$Site = 'site')
$ErrorActionPreference = 'Stop'
# Any problem is shown on the run's summary page, so it's easy to report.
trap { Write-Host "::error title=PDF Air build step failed::$($_.Exception.Message)"; exit 1 }
$www = (Resolve-Path $Site).Path
$html = Join-Path $www 'index.html'
$page = Get-Content $html -Raw -Encoding utf8
$ua = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15'

# 1. PDF engine
$libs = [ordered]@{
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js' = 'pdf.min.js'
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js' = 'pdf.worker.min.js'
  'https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js' = 'pdf-lib.min.js'
  'https://cdn.jsdelivr.net/npm/@pdf-lib/fontkit@1.1.1/dist/fontkit.umd.min.js' = 'fontkit.umd.min.js'
}
New-Item -ItemType Directory -Force (Join-Path $www 'lib') | Out-Null
foreach ($u in $libs.Keys) {
  $f = Join-Path $www ('lib/' + $libs[$u])
  if (-not (Test-Path $f)) { Invoke-WebRequest $u -OutFile $f -UseBasicParsing }
  $page = $page.Replace($u, 'lib/' + $libs[$u])
}

# 2. Fonts (calligraphy, handwriting, signatures and the interface font)
$m = [regex]::Match($page, 'https://fonts\.googleapis\.com/css2\?[^"]+')
if ($m.Success) {
  $css = (Invoke-WebRequest $m.Value -Headers @{ 'User-Agent' = $ua } -UseBasicParsing).Content
  New-Item -ItemType Directory -Force (Join-Path $www 'fonts') | Out-Null
  $script:n = 0
  $css = [regex]::Replace($css, 'url\((https://[^)]+)\)', {
    param($x)
    $script:n++
    $u = $x.Groups[1].Value
    $name = 'f' + $script:n + [IO.Path]::GetExtension(([Uri]$u).AbsolutePath)
    Invoke-WebRequest $u -OutFile (Join-Path $www ('fonts/' + $name)) -UseBasicParsing
    'url(' + $name + ')'
  })
  Set-Content (Join-Path $www 'fonts/fonts.css') $css -Encoding utf8NoBOM
  $page = $page.Replace($m.Value, 'fonts/fonts.css')
  if ($page -notmatch 'PDFAIR_FONTS_LOCAL') { $page = ([regex]'<head>').Replace($page, '<head><script>window.PDFAIR_FONTS_LOCAL = true;</script>', 1) }
}
# 2b. Text recognition (OCR): engine plus English, Japanese, Korean, Traditional Chinese and Vietnamese
try {
  $ocr = [ordered]@{
  'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js' = 'tesseract.min.js'
  'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/worker.min.js' = 'worker.min.js'
  'https://cdn.jsdelivr.net/npm/tesseract.js-core@5.1.1/tesseract-core-simd-lstm.wasm.js' = 'tesseract-core-simd-lstm.wasm.js'
  'https://cdn.jsdelivr.net/npm/tesseract.js-core@5.1.1/tesseract-core-lstm.wasm.js' = 'tesseract-core-lstm.wasm.js'
  'https://cdn.jsdelivr.net/npm/@tesseract.js-data/eng/4.0.0_best_int/eng.traineddata.gz' = 'lang/eng.traineddata.gz'
  'https://cdn.jsdelivr.net/npm/@tesseract.js-data/jpn/4.0.0_best_int/jpn.traineddata.gz' = 'lang/jpn.traineddata.gz'
  'https://cdn.jsdelivr.net/npm/@tesseract.js-data/kor/4.0.0_best_int/kor.traineddata.gz' = 'lang/kor.traineddata.gz'
  'https://cdn.jsdelivr.net/npm/@tesseract.js-data/chi_tra/4.0.0_best_int/chi_tra.traineddata.gz' = 'lang/chi_tra.traineddata.gz'
  'https://cdn.jsdelivr.net/npm/@tesseract.js-data/vie/4.0.0_best_int/vie.traineddata.gz' = 'lang/vie.traineddata.gz'
  }
  New-Item -ItemType Directory -Force (Join-Path $www 'ocr/lang') | Out-Null
  foreach ($u in $ocr.Keys) { $f = Join-Path $www ('ocr/' + $ocr[$u]); if (-not (Test-Path $f)) { Invoke-WebRequest $u -OutFile $f -UseBasicParsing } }
  if ($page -notmatch 'PDFAIR_OCR_LOCAL') { $page = ([regex]'<head>').Replace($page, '<head><script>window.PDFAIR_OCR_LOCAL = true;</script>', 1) }
} catch { Write-Host "PDF Air: OCR bundling skipped ($_). OCR will load online." }
Set-Content $html $page -Encoding utf8NoBOM -NoNewline

# Offline store: what it keeps, and a new name for every build so iPads pick up updates.
$rel = { param($f) './' + [IO.Path]::GetRelativePath($www, $f.FullName).Replace('\', '/') }
$all = Get-ChildItem $www -Recurse -File | Where-Object { $_.Name -ne 'sw.js' }
$core = @('./') + ($all | Where-Object { $r = & $rel $_; $r -notmatch '^\./(fonts|ocr)/' -or $r -eq './fonts/fonts.css' } | ForEach-Object { & $rel $_ })
$extra = $all | Where-Object { $r = & $rel $_; $r -match '^\./(fonts|ocr)/' -and $r -ne './fonts/fonts.css' } | ForEach-Object { & $rel $_ }
$ver = [regex]::Match($page, 'APP_VERSION = "([^"]+)"').Groups[1].Value
$build = if ($env:GITHUB_SHA) { $env:GITHUB_SHA.Substring(0, 7) } else { [DateTime]::UtcNow.ToString('yyyyMMddHHmm') }
$sw = Get-Content (Join-Path $www 'sw.js') -Raw -Encoding utf8
$sw = $sw.Replace('__VERSION__', $ver).Replace('__BUILD__', $build)
$sw = $sw.Replace('__CORE__', (ConvertTo-Json -InputObject @($core) -Compress)).Replace('__EXTRA__', (ConvertTo-Json -InputObject @($extra) -Compress))
Set-Content (Join-Path $www 'sw.js') $sw -Encoding utf8NoBOM -NoNewline
Write-Host "PDF Air $ver for iPad: $($core.Count) core files and $($extra.Count) font and text-recognition files are built in."
