// PDF Air for iPad: keeps the app working with no internet.
// The build fills in the version and the file lists below.
const VERSION = '__VERSION__-__BUILD__';
const CORE = __CORE__;     // needed to open, edit and save PDFs: stored when the app is added
const EXTRA = __EXTRA__;   // fonts and text recognition: stored in the background afterwards
const CACHE = 'pdfair-ipad-' + VERSION;

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== CACHE) await caches.delete(k);
    await self.clients.claim();
  })());
  // Store the extras one by one; anything that fails is fetched again the next time it's needed.
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    for (const u of EXTRA) { try { if (!(await c.match(u))) await c.add(u); } catch (_) {} }
  })());
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  if (req.mode === 'navigate') {
    // Opening the app always works offline: serve the stored page.
    e.respondWith(caches.match('./index.html').then(hit => hit || fetch(req)));
    return;
  }
  e.respondWith(caches.match(req, { ignoreSearch: true }).then(hit => hit || fetch(req).then(r => {
    if (r.ok) { const copy = r.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
    return r;
  })));
});
